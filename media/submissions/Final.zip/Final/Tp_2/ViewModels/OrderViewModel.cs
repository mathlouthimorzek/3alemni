﻿using System.ComponentModel.DataAnnotations;

namespace Tp_2.ViewModels
{
    public class OrderViewModel
    {
        [Required]
        public string CustomerName { get; set; }
        [Required, EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Address { get; set; }
        public List<CartItemViewModel> CartItems { get;  set; }
        public float TotalAmount { get;  set; }

    }
}
