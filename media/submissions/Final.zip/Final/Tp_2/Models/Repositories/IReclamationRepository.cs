﻿namespace Tp_2.Models.Repositories
{
    public interface IReclamationRepository
    {
        IList<Reclamation> GetAll();
        Reclamation GetById(int id);
        void Add(Reclamation r);
        IList<Reclamation> FindByProductName(string productName);
        Reclamation Update(Reclamation r);
        void Delete(int reclamationId);
        IQueryable<Reclamation> GetAllReclamations();
        void Add(Intervention intervention);
    }
}
