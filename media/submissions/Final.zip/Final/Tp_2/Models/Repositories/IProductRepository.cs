﻿using System.ComponentModel.DataAnnotations;

namespace Tp_2.Models.Repositories
{
    public interface IProductRepository
    {
        Product GetById(int Id);
        IList<Product> GetAll();
        void Add(Product t);
        Product Update(Product t);
        void Delete(int Id);
        public IQueryable<Product> GetAllProducts();
        public IList<Product> GetProductsByCategID(int? CategId);
        public IList<Product> FindByName(string name);
    }
}
