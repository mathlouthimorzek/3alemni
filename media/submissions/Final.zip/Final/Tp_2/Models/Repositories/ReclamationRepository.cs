﻿using Microsoft.EntityFrameworkCore;

namespace Tp_2.Models.Repositories
{
    public class ReclamationRepository : IReclamationRepository
    {
        readonly AppDbContext context;

        public ReclamationRepository(AppDbContext context)
        {
            this.context = context;
        }

        public IList<Reclamation> GetAll()
        {
            return context.Reclamations
                .OrderBy(r => r.ReclamationId)
                .ToList();
        }

        public Reclamation GetById(int id)
        {
            return context.Reclamations
                .Where(r => r.ReclamationId == id)
                .SingleOrDefault();
        }

        public void Add(Reclamation r)
        {
            context.Reclamations.Add(r);
            context.SaveChanges();
        }

        public IList<Reclamation> FindByProductName(string productName)
        {
            return context.Reclamations
                .Where(r => r.ProductName.Contains(productName))
                .ToList();
        }

        public Reclamation Update(Reclamation r)
        {
            Reclamation existing = context.Reclamations.Find(r.ReclamationId);
            if (existing != null)
            {
                existing.ProductName = r.ProductName;
                existing.Mail = r.Mail;
                existing.Address = r.Address;
                existing.ReclamationDetail = r.ReclamationDetail;
                existing.ExpectedResult = r.ExpectedResult;

                context.SaveChanges();
            }
            return existing;
        }

        public void Delete(int reclamationId)
        {
            Reclamation r = context.Reclamations.Find(reclamationId);
            if (r != null)
            {
                context.Reclamations.Remove(r);
                context.SaveChanges();
            }
        }

        public IQueryable<Reclamation> GetAllReclamations()
        {
            return context.Reclamations.AsQueryable();
        }

        public void Add(Intervention intervention)
        {
            throw new NotImplementedException();
        }
    }
}
