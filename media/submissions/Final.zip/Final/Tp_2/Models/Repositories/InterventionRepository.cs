﻿using Microsoft.EntityFrameworkCore;


namespace Tp_2.Models.Repositories
{
    public class InterventionRepository : IInterventionRepository
    {
        private readonly AppDbContext _context;
        public InterventionRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Intervention> GetAll()
        {
            return _context.Interventions.Include(i => i.Reclamation).ToList();
        }

        public Intervention GetById(int id)
        {
            return _context.Interventions.Include(i => i.Reclamation)
                                         .FirstOrDefault(i => i.InterventionId == id);
        }

        public void Add(Intervention intervention)
        {
            _context.Interventions.Add(intervention);
            _context.SaveChanges();
        }

        public void Update(Intervention intervention)
        {
            _context.Interventions.Update(intervention);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var i = GetById(id);
            if (i != null)
            {
                _context.Interventions.Remove(i);
                _context.SaveChanges();
            }
        }
    }


}

