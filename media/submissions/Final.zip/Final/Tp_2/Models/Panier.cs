﻿namespace Tp_2.Models
{
    public class Panier
    {
        public int PanierId { get; set; }
    }
}
