﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tp_2.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 5)]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Prix en dinar :")]
        public float Price { get; set; }

        [Required]
        [Display(Name = "Quantité en unité :")]
        public int QteStock { get; set; }

        public int CategoryId { get; set; }
        public Category Category { get; set; }

        [Required]
        [Display(Name = "Image :")]
        public string Image { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date d'achat :")]
        public DateTime DateAchat { get; set; }

        // Propriété calculée : Date d'expiration de garantie = DateAchat + 1 an
        [NotMapped]
        [Display(Name = "Expire le :")]
        public DateTime GarantieExpireLe
        {
            get { return DateAchat.AddYears(1); }
        }
    }
}
