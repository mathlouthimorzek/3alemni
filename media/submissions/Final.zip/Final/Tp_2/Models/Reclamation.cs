﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tp_2.Models
{
    public class Reclamation
    {
        [Key]
        public int ReclamationId { get; set; }

        [Required]
        [Display(Name = "Produit Réclamé")]
        public string ProductName { get; set; } // Remarque : juste le nom du produit

        [Required]
        [EmailAddress]
        public string Mail { get; set; }

        [Required]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }

        [Required]
        [Display(Name = "Détail de la Réclamation")]
        [DataType(DataType.MultilineText)]
        public string ReclamationDetail { get; set; }

        [Required]
        [Display(Name = "Résultat Souhaité")]
        [DataType(DataType.MultilineText)]
        public string ExpectedResult { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date de Réclamation")]
        public DateTime DateReclamation { get; set; }
    }
}
