﻿using System.ComponentModel.DataAnnotations;

namespace Tp_2.Models
{
    public class Intervention
    {
        public int InterventionId { get; set; }
        public int ReclamationId { get; set; }
        public Reclamation Reclamation { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateIntervention { get; set; } = DateTime.Now;

        public bool EstSousGarantie { get; set; }

        public decimal CoutPieces { get; set; }

        public decimal CoutMainOeuvre { get; set; }

        public decimal TotalFacture => EstSousGarantie ? 0 : CoutPieces + CoutMainOeuvre;
    }


}

