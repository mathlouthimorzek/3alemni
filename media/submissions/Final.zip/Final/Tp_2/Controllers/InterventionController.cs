﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Tp_2.Models;

namespace Tp_2.Controllers
{
    public class InterventionController : Controller
    {
        private readonly AppDbContext _context;

        public InterventionController(AppDbContext context)
        {
            _context = context;
        }
        
        // GET: Intervention
        public IActionResult Index()
        {
            var interventions = _context.Interventions.Include(i => i.Reclamation).ToList();
            return View(interventions);
        }

        // GET: Intervention/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();

            var intervention = _context.Interventions
                .Include(i => i.Reclamation)
                .FirstOrDefault(m => m.InterventionId == id);

            if (intervention == null)
                return NotFound();

            return View(intervention);
        }
        [Authorize(Roles = "Admin")]
        // GET: Intervention/Create
        public IActionResult Create()
        {
            ViewBag.ReclamationId = new SelectList(_context.Reclamations.ToList(), "ReclamationId", "ProductName");
            return View();
        }
        [Authorize(Roles = "Admin")]
        // POST: Intervention/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Intervention intervention)
        {
            try
            {
                _context.Add(intervention);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception) { 
            ViewBag.ReclamationId = new SelectList(_context.Reclamations.ToList(), "ReclamationId", "ProductName", intervention.ReclamationId);
            return View(intervention);}
        }
    }
}
