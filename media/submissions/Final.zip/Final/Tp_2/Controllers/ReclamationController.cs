﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tp_2.Models;
using Tp_2.Models.Repositories;

namespace Tp_2.Controllers
{
    //[Authorize(Roles = "Admin,Manager")] // Protège TOUT sauf Create
    public class ReclamationController : Controller
    {
        private readonly IReclamationRepository _repository;

        public ReclamationController(IReclamationRepository repository)
        {
            _repository = repository;
        }
        [Authorize(Roles = "Admin")]
        // Afficher liste des réclamations
        public IActionResult Index()
        {
            var reclamations = _repository.GetAll();
            return View(reclamations);
        }

        // Détail d'une réclamation
        public IActionResult Details(int id)
        {
            var reclamation = _repository.GetById(id);
            if (reclamation == null)
            {
                return NotFound();
            }
            return View(reclamation);
        }

        // Formulaire de création
        //[AllowAnonymous] // Permet à tout utilisateur non connecté OU connecté
        public IActionResult Create()
        {
            return View();
        }

        // Enregistrer réclamation (POST)
        [HttpPost][ValidateAntiForgeryToken]
        public IActionResult Create(Reclamation reclamation)
        {

            try {
                _repository.Add(reclamation);
                return RedirectToAction("Index");
            }
            catch (Exception) {
                return View();
            } 
        }

        // Formulaire d'édition
        public IActionResult Edit(int id)
        {
            var reclamation = _repository.GetById(id);
            if (reclamation == null)
            {
                return NotFound();
            }
            return View(reclamation);
        }

        // Enregistrer modification (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Reclamation reclamation)
        {
            if (id != reclamation.ReclamationId)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                _repository.Update(reclamation);
                return RedirectToAction(nameof(Index));
            }
            return View(reclamation);
        }

        // Supprimer (confirmation)
        public IActionResult Delete(int id)
        {
            var reclamation = _repository.GetById(id);
            if (reclamation == null)
            {
                return NotFound();
            }
            return View(reclamation);
        }

        // Supprimer définitivement (POST)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            _repository.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
