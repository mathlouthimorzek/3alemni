﻿namespace Tp_2.Views.Shared
{
    public class Class
    {
    }
}
